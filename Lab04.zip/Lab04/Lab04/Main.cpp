#include <iostream>
#include <string>
#include "time.h"

bool isPanlindrome(std::string word, int start, int end)
{
	if (end - start == 0 || start == end)
		return true;
	else if (word[start] == word[end])
		return isPanlindrome(word, start+=1, end-=1);
	else
		return false;
}

void swap(int* a, int* b)
{
	int t = *a;
	*a = *b;
	*b = t;
}

void swapLetters(std::string* a, std::string* b)
{
	std::string t = *a;
	*a = *b;
	*b = t;
}

int partition(int numbers[], int start, int end)
{
	int pivot = numbers[end];
	int i = start - 1;

	for (int j = start; j <= end - 1; j++)
	{
		if (numbers[j] <= pivot)
		{
			i++;
			swap(&numbers[i], &numbers[j]);
		}
	}

	swap(&numbers[i + 1], &numbers[end]);
	return i + 1;
}

void quickSort(int numbers[], int start, int end)
{
	if (start < end)
	{
		int par = partition(numbers, start, end);

		quickSort(numbers, start, par - 1);
		quickSort(numbers, par + 1, end);
	}
}

void showSort(int numbers[], int position)
{
	for (int i = 0; i < 9; i++)
	{
		std::cout << std::endl;
		for (int j = 0; j < numbers[i]; j++)
		{
			std::cout << "*";
		}
	}
	std::cout << std::endl;
}

void reverseString(const std::string word)
{
	int wordLength;

	wordLength = word.length();

	if (wordLength == 1)
		std::cout << word << std::endl;
	else 
	{
		std::cout << word[wordLength - 1];
		reverseString(word.substr(0, wordLength - 1));
	}
}

void showMenu()
{
	std::cout << "Pick an Option" << std::endl;
	std::cout << "--------------" << std::endl;
	std::cout << "1. Palindrome Checker\n2. Quick Sort Algorithm\n3. Reverse a String\n4. Exit" << std::endl;
}

int main()
{
	std::string word;
	int choice, wordLength;
	srand(time(NULL));

	int numbers[] = { rand() % 10, rand() % 10, rand() % 10, rand() % 10, rand() % 10, rand() % 10, rand() % 10, rand() % 10, rand() % 10, rand() % 10 };
	
	showMenu();
	std::cin >> choice;

	switch (choice)
	{
	case 1:
		system("CLS");

		std::cout << "What word would you like to check: ";
		std::cin >> word;

		wordLength = word.length();

		if (isPanlindrome(word, 0, wordLength - 1))
		{
			for (int i = 0; i < wordLength; i++)
			{
				if (i + 1 != wordLength)
				{
					std::cout << word[i] << "-";
				}
				else
				{
					std::cout << word[i];
				}
			}
			std::cout << " is a Palindrome" << std::endl;
		}
		else
		{
			for (int i = 0; i < wordLength; i++)
			{
				if (i + 1 != wordLength)
				{
					std::cout << word[i] << "-";
				}
				else
				{
					std::cout << word[i];
				}
			}
			std::cout << " is not a Palindrome" << std::endl;
		}
		break;
	case 2:
		system("CLS");

		std::cout << "Unsorted list: ";
		for (int i = 0; i < 9; i++)
		{
			if (i + 1 != 9)
			{
				std::cout << numbers[i] << ", ";
			}
			else
			{
				std::cout << numbers[i] << std::endl;
			}
		}
		showSort(numbers, 9);

		quickSort(numbers, 0, 9);
		std::cout << "Sorted list: ";
		for (int j = 0; j < 9; j++)
		{
			if (j + 1 != 9)
			{
				std::cout << numbers[j] << ", ";
			}
			else
			{
				std::cout << numbers[j] << std::endl;
			}
		}
		showSort(numbers, 9);
		break;
	case 3:
		system("CLS");

		std::cout << "Enter a Word: ";
		std::cin >> word;

		std::cout << "Reversed Word: ";
		reverseString(word);
		break;
	default:
		break;
	}
}